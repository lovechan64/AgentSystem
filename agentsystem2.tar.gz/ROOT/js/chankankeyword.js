$().ready(function(){
	mover(2); 
	});
	
	
 