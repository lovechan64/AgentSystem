package org.agent.pojo;

 
public class Province  extends Base    {

 
	private String provinceId;
	private String province;
	public String getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(String provinceId) {
		this.provinceId = provinceId;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
 

}