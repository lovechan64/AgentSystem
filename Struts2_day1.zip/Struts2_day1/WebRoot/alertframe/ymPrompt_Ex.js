try{ymPrompt=top.ymPrompt}catch(e){}
